import UIKit

var one = "A ham sandwich walks into a bar and orders a beer"
var two = "Bartender says we dont serve food here"

print(one + "\n")
print("\t" + two)

